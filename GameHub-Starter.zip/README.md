# GameHub Starter

A simple responsive browser-game portal made with HTML, CSS, and JavaScript.

## Run it

You can open `index.html` directly for a basic preview, or use a local server:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Add a game

1. Create a folder under `games/`.
2. Put the game's `index.html` and assets there.
3. Add an entry to the `games` array in `script.js`.
4. Test the Play button.

## Important

Only distribute games you created yourself or games whose license/permission allows redistribution.
