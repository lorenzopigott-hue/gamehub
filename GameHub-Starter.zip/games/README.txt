Put your own HTML5 games in this folder.

For example:
games/
  pixel-racer/
    index.html
  my-game/
    index.html

Then add the game to the games array in ../script.js.

Only host games you created yourself or have permission/license rights to distribute.
