(() => {
  'use strict';

  const TAU = Math.PI * 2;
  const clamp = (v,a,b) => Math.max(a, Math.min(b,v));
  const lerp = (a,b,t) => a + (b-a)*t;
  const dist2 = (a,b) => { const x=a.x-b.x, z=a.z-b.z; return x*x+z*z; };
  const rnd = (a=0,b=1) => a + Math.random()*(b-a);
  const pick = a => a[(Math.random()*a.length)|0];
  const now = () => performance.now()/1000;
  const mulberry32 = seed => () => { let t=seed += 0x6D2B79F5; t=Math.imul(t^t>>>15,t|1); t^=t+Math.imul(t^t>>>7,t|61); return ((t^t>>>14)>>>0)/4294967296; };
  const worldRand = mulberry32(7283941);
  const wrnd = (a=0,b=1) => a + worldRand()*(b-a);
  const wpick = a => a[(worldRand()*a.length)|0];

  const canvas = document.getElementById('game');
  let gl, isWebGL2=false, vaoExt=null;
  try { gl = canvas.getContext('webgl2', { antialias:true, alpha:false, powerPreference:'high-performance' }); isWebGL2=!!gl; } catch(e) { gl=null; }
  if (!gl) { try { gl=canvas.getContext('webgl', {antialias:true, alpha:false, powerPreference:'high-performance'}) || canvas.getContext('experimental-webgl'); } catch(e) { gl=null; } }
  if (!gl) {
    const fatal=document.getElementById('fatal');
    const txt=document.getElementById('fatalText');
    if(fatal){ fatal.classList.remove('hidden'); if(txt) txt.textContent='Your browser could not start 3D graphics. The game supports WebGL 1 and WebGL 2; reload the page or enable hardware acceleration in Chrome.'; }
    return;
  }

  const TEST = new URLSearchParams(location.search).has('test');
  window.__DINO_FRONTIER__ = { booted:false, test:TEST, errors:[] };

  const vertexSource = isWebGL2 ? `#version 300 es
    in vec3 aPos; in vec3 aNormal;
    uniform mat4 uProj; uniform mat4 uView; uniform mat4 uModel;
    uniform vec3 uLight;
    out vec3 vN; out vec3 vWorld; out float vH;
    void main(){ vec4 w=uModel*vec4(aPos,1.0); vWorld=w.xyz; vN=mat3(uModel)*aNormal; vH=w.y; gl_Position=uProj*uView*w; }
  ` : `attribute vec3 aPos; attribute vec3 aNormal;
    uniform mat4 uProj; uniform mat4 uView; uniform mat4 uModel;
    uniform vec3 uLight;
    varying vec3 vN; varying vec3 vWorld; varying float vH;
    void main(){ vec4 w=uModel*vec4(aPos,1.0); vWorld=w.xyz; vN=mat3(uModel)*aNormal; vH=w.y; gl_Position=uProj*uView*w; }
  `;
  const fragmentSource = isWebGL2 ? `#version 300 es
    precision highp float;
    in vec3 vN; in vec3 vWorld; in float vH;
    uniform vec4 uColor; uniform vec3 uSun; uniform vec3 uFog; uniform float uFogNear; uniform float uFogFar; uniform int uTerrain;
    out vec4 outColor;
    void main(){ vec3 n=normalize(vN); float light=.45+.55*max(dot(n,normalize(uSun)),0.0); vec3 c=uColor.rgb; if(uTerrain==1){ float h=smoothstep(6.0,14.0,vH); c=mix(vec3(.075,.22,.11),vec3(.30,.40,.19),h); float warm=smoothstep(-120.0,-45.0,vWorld.x)*smoothstep(25.0,-20.0,vWorld.z); c=mix(c,vec3(.48,.35,.16),warm*.55); float frost=smoothstep(62.0,105.0,vWorld.z)+smoothstep(18.0,25.0,vH); c=mix(c,vec3(.67,.73,.72),clamp(frost,0.0,1.0)*.72); float jungle=smoothstep(45.0,100.0,vWorld.x)*smoothstep(20.0,105.0,vWorld.z); c=mix(c,vec3(.10,.30,.17),jungle*.5); float coast=smoothstep(-105.0,-75.0,vWorld.z); c=mix(c,vec3(.56,.48,.28),coast*.32); } c*=light; float d=length(vWorld); float f=clamp((d-uFogNear)/(uFogFar-uFogNear),0.0,1.0); c=mix(c,uFog,f); outColor=vec4(c,uColor.a); }
  ` : `precision highp float;
    varying vec3 vN; varying vec3 vWorld; varying float vH;
    uniform vec4 uColor; uniform vec3 uSun; uniform vec3 uFog; uniform float uFogNear; uniform float uFogFar; uniform int uTerrain;
    void main(){ vec3 n=normalize(vN); float light=.45+.55*max(dot(n,normalize(uSun)),0.0); vec3 c=uColor.rgb; if(uTerrain==1){ float h=smoothstep(6.0,14.0,vH); c=mix(vec3(.075,.22,.11),vec3(.30,.40,.19),h); float warm=smoothstep(-120.0,-45.0,vWorld.x)*smoothstep(25.0,-20.0,vWorld.z); c=mix(c,vec3(.48,.35,.16),warm*.55); float frost=smoothstep(62.0,105.0,vWorld.z)+smoothstep(18.0,25.0,vH); c=mix(c,vec3(.67,.73,.72),clamp(frost,0.0,1.0)*.72); float jungle=smoothstep(45.0,100.0,vWorld.x)*smoothstep(20.0,105.0,vWorld.z); c=mix(c,vec3(.10,.30,.17),jungle*.5); float coast=smoothstep(-105.0,-75.0,vWorld.z); c=mix(c,vec3(.56,.48,.28),coast*.32); } c*=light; float d=length(vWorld); float f=clamp((d-uFogNear)/(uFogFar-uFogNear),0.0,1.0); c=mix(c,uFog,f); gl_FragColor=vec4(c,uColor.a); }
  `;

  function makeShader(type, src){ const s=gl.createShader(type); gl.shaderSource(s,src); gl.compileShader(s); if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }
  const program = gl.createProgram();
  gl.attachShader(program, makeShader(gl.VERTEX_SHADER,vertexSource));
  gl.attachShader(program, makeShader(gl.FRAGMENT_SHADER,fragmentSource));
  gl.linkProgram(program);
  if(!gl.getProgramParameter(program,gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
  gl.useProgram(program);
  const A={pos:gl.getAttribLocation(program,'aPos'),normal:gl.getAttribLocation(program,'aNormal')};
  const U={proj:gl.getUniformLocation(program,'uProj'),view:gl.getUniformLocation(program,'uView'),model:gl.getUniformLocation(program,'uModel'),color:gl.getUniformLocation(program,'uColor'),sun:gl.getUniformLocation(program,'uSun'),fog:gl.getUniformLocation(program,'uFog'),fogNear:gl.getUniformLocation(program,'uFogNear'),fogFar:gl.getUniformLocation(program,'uFogFar'),terrain:gl.getUniformLocation(program,'uTerrain')};

  const Mat={
    identity(){const m=new Float32Array(16);m[0]=m[5]=m[10]=m[15]=1;return m;},
    perspective(fovy,aspect,n,f){const m=new Float32Array(16),t=1/Math.tan(fovy/2);m[0]=t/aspect;m[5]=t;m[10]=(f+n)/(n-f);m[11]=-1;m[14]=(2*f*n)/(n-f);return m;},
    look(eye,center,up=[0,1,0]){let zx=eye[0]-center[0],zy=eye[1]-center[1],zz=eye[2]-center[2],zl=Math.hypot(zx,zy,zz)||1;zx/=zl;zy/=zl;zz/=zl;let xx=up[1]*zz-up[2]*zy,xy=up[2]*zx-up[0]*zz,xz=up[0]*zy-up[1]*zx,xl=Math.hypot(xx,xy,xz)||1;xx/=xl;xy/=xl;xz/=xl;let yx=zy*xz-zz*xy,yy=zz*xx-zx*xz,yz=zx*xy-zy*xx;const m=Mat.identity();m[0]=xx;m[1]=yx;m[2]=zx;m[4]=xy;m[5]=yy;m[6]=zy;m[8]=xz;m[9]=yz;m[10]=zz;m[12]=-(xx*eye[0]+xy*eye[1]+xz*eye[2]);m[13]=-(yx*eye[0]+yy*eye[1]+yz*eye[2]);m[14]=-(zx*eye[0]+zy*eye[1]+zz*eye[2]);return m;},
    trs(p,r,s){const [cx,sx]=[Math.cos(r[0]),Math.sin(r[0])],[cy,sy]=[Math.cos(r[1]),Math.sin(r[1])],[cz,sz]=[Math.cos(r[2]),Math.sin(r[2])];const m=Mat.identity();m[0]=(cy*cz)*s[0];m[1]=(sx*sy*cz+cx*sz)*s[0];m[2]=(-cx*sy*cz+sx*sz)*s[0];m[4]=(-cy*sz)*s[1];m[5]=(-sx*sy*sz+cx*cz)*s[1];m[6]=(cx*sy*sz+sx*cz)*s[1];m[8]=sy*s[2];m[9]=-sx*cy*s[2];m[10]=cx*cy*s[2];m[12]=p[0];m[13]=p[1];m[14]=p[2];return m;},
    mulVecY(p,yaw,dx,dz){const c=Math.cos(yaw),s=Math.sin(yaw);return {x:p.x+dx*c-dz*s,y:p.y,z:p.z+dx*s+dz*c};}
  };

  vaoExt = !isWebGL2 ? gl.getExtension('OES_vertex_array_object') : null;
  const bindVAO = v => isWebGL2 ? gl.bindVertexArray(v) : vaoExt ? vaoExt.bindVertexArrayOES(v) : undefined;
  const createVAO = () => isWebGL2 ? gl.createVertexArray() : vaoExt ? vaoExt.createVertexArrayOES() : null;
  function makeMesh(positions,normals,indices){
    const vao=createVAO(); bindVAO(vao);
    const pb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,pb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(positions),gl.STATIC_DRAW);gl.enableVertexAttribArray(A.pos);gl.vertexAttribPointer(A.pos,3,gl.FLOAT,false,0,0);
    const nb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,nb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(normals),gl.STATIC_DRAW);gl.enableVertexAttribArray(A.normal);gl.vertexAttribPointer(A.normal,3,gl.FLOAT,false,0,0);
    const ib=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);const idx=new Uint16Array(indices);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,idx,gl.STATIC_DRAW);
    bindVAO(null); return {vao,count:idx.length};
  }
  function boxMesh(){
    const p=[-1,-1,-1,1,-1,-1,1,1,-1,-1,1,-1,-1,-1,1,1,-1,1,1,1,1,-1,1,1], n=[0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,1,0,0,1,0,0,1,0,0,1,-1,0,0,-1,0,0,-1,0,0,-1,0,0,1,0,0,1,0,0,1,0,0,1,0,0];
    const inds=[0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,1,5,6,1,6,2,0,3,7,0,7,4];
    return makeMesh(p,n,inds);
  }
  function sphereMesh(seg=10,rings=6){const p=[],n=[],i=[];for(let y=0;y<=rings;y++){const v=y/rings,ph=v*Math.PI;for(let x=0;x<=seg;x++){const u=x/seg,th=u*TAU,s=Math.sin(ph);p.push(Math.cos(th)*s,Math.cos(ph),Math.sin(th)*s);n.push(Math.cos(th)*s,Math.cos(ph),Math.sin(th)*s)}}const w=seg+1;for(let y=0;y<rings;y++)for(let x=0;x<seg;x++){const a=y*w+x,b=a+1,c=a+w,d=c+1;i.push(a,c,b,b,c,d)}return makeMesh(p,n,i);}
  function coneMesh(seg=10){const p=[],n=[],i=[];p.push(0,1,0);n.push(0,1,0);p.push(0,-1,0);n.push(0,-1,0);for(let x=0;x<seg;x++){const a=x/seg*TAU,c=Math.cos(a),s=Math.sin(a);p.push(c,-1,s,c,1,s);n.push(c,0,s,c,0,s)}for(let x=0;x<seg;x++){const b=2+x*2, t=b+1, nb=2+((x+1)%seg)*2, nt=nb+1;i.push(b,t,nt,b,nt,nb,0,nt,t,1,b,nb,b,nb,t)}return makeMesh(p,n,i);}
  function planeMesh(size,div){const p=[],n=[],i=[],step=size/div;for(let z=0;z<=div;z++){const zz=-size/2+z*step;for(let x=0;x<=div;x++){const xx=-size/2+x*step,h=heightAt(xx,zz);p.push(xx,h,zz);const e=.15,dx=heightAt(xx+e,zz)-heightAt(xx-e,zz),dz=heightAt(xx,zz+e)-heightAt(xx,zz-e);let nx=-dx,ny=2*e,nz=-dz,l=Math.hypot(nx,ny,nz)||1;n.push(nx/l,ny/l,nz/l)}}const w=div+1;for(let z=0;z<div;z++)for(let x=0;x<div;x++){const a=z*w+x,b=a+1,c=a+w,d=c+1;i.push(a,c,b,b,c,d)}return makeMesh(p,n,i);}

  const MESH={box:boxMesh(), sphere:sphereMesh(), cone:coneMesh(), terrain:null};
  function heightAt(x,z){return 3.25 + 1.2*Math.sin(x*.026)+.9*Math.cos(z*.031)+.55*Math.sin((x+z)*.045)+.35*Math.cos((x-z)*.09) + 2.7*Math.exp(-((x+35)**2+(z-20)**2)/900);}
  MESH.terrain=planeMesh(250,105);

  gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
  gl.clearColor(.06,.1,.11,1);

  function resize(){const d=Math.min(devicePixelRatio||1,1.7),w=Math.floor(innerWidth*d),h=Math.floor(innerHeight*d);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}}
  addEventListener('resize',resize); resize();

  const scene={
    time:0, day:0.22, weather:0, rain:0, objects:[], dinos:[], resources:[], builds:[], farms:[], particles:[], remotes:new Map(), camera:{yaw:0,pitch:-.18,dist:7}, selected:null, buildMode:false, buildChoice:0, mounted:null, running:true
  };

  const species={
    trike:{name:'Triceratops',diet:'HERBIVORE',speed:3.2,hp:170,tame:5,color:[.46,.36,.24],accent:[.8,.67,.37],size:1.35,aggro:7,ride:true},
    stego:{name:'Stegosaurus',diet:'HERBIVORE',speed:2.5,hp:150,tame:5,color:[.28,.44,.31],accent:[.72,.51,.32],size:1.25,aggro:7,ride:true},
    anky:{name:'Ankylosaurus',diet:'HERBIVORE',speed:2.2,hp:190,tame:6,color:[.34,.33,.3],accent:[.53,.62,.43],size:1.15,aggro:6,ride:true},
    para:{name:'Parasaurolophus',diet:'HERBIVORE',speed:4.2,hp:115,tame:4,color:[.22,.37,.47],accent:[.69,.47,.36],size:1.05,aggro:9,ride:true},
    rex:{name:'Tyrannosaur',diet:'PREDATOR',speed:4.7,hp:280,tame:10,color:[.36,.26,.23],accent:[.72,.46,.25],size:1.5,aggro:25,ride:true},
    carno:{name:'Carnotaurus',diet:'PREDATOR',speed:5.4,hp:205,tame:8,color:[.48,.22,.2],accent:[.85,.56,.31],size:1.15,aggro:22,ride:true},
    raptor:{name:'Velociraptor',diet:'PREDATOR',speed:6.4,hp:80,tame:7,color:[.18,.23,.22],accent:[.58,.72,.48],size:.8,aggro:18,ride:false},
    ptera:{name:'Pteranodon',diet:'FISH',speed:7.1,hp:65,tame:6,color:[.33,.26,.35],accent:[.74,.63,.48],size:.78,aggro:14,ride:true,fly:true},
    titan:{name:'Elder Titan',diet:'HERBIVORE',speed:2.9,hp:650,tame:999,color:[.33,.24,.18],accent:[.92,.67,.20],size:2.35,aggro:22,ride:false,boss:true}
  };

  const player={name:'Explorer',x:0,y:0,z:4,yaw:0,vy:0,hp:100,maxHp:100,st:100,hunger:100,thirst:100,temp:50,xp:0,level:1,wood:0,stone:0,berries:5,seeds:3,water:2,meat:1,fiber:0,crystal:0,clay:0,fish:0,food:1,builds:0,tames:[],discoveries:{},alive:true,cool:0,damageCooldown:0};
  const quest={id:'camp',title:'The First Camp',desc:'Gather 10 wood to make your first shelter.',target:10,get:()=>player.wood,reward:'level'};
  const questList=[
    quest,
    {id:'garden',title:'Green Thumb',desc:'Plant and harvest 3 garden plots.',target:3,get:()=>scene.farms.filter(f=>f.harvests>0).length,reward:'seeds'},
    {id:'friend',title:'A New Companion',desc:'Earn the trust of a wild herbivore.',target:1,get:()=>player.tames.length,reward:'xp'},
    {id:'scout',title:'Into the Unknown',desc:'Discover 4 landmarks.',target:4,get:()=>Object.keys(player.discoveries).length,reward:'xp'}
  ];
  let questIndex=0;

  const keys=new Set(); let mouseDX=0,mouseDY=0,locked=false;
  addEventListener('keydown',e=>{keys.add(e.code); if(['Space','KeyW','KeyA','KeyS','KeyD'].includes(e.code))e.preventDefault(); if(e.code==='KeyI')toggleModal('invModal'); if(e.code==='KeyM')toggleModal('mapModal'); if(e.code==='KeyB')toggleBuild(); if(e.code==='KeyR')rideNearest(); if(e.code==='KeyC')commandMounted(); if(e.code==='Digit1')scene.buildChoice=0; if(e.code==='Digit2')scene.buildChoice=1; if(e.code==='Digit3')scene.buildChoice=2; if(e.code==='Digit4')scene.buildChoice=3; if(e.code.startsWith('Digit'))updateBuildHUD(); if(e.code==='Escape'){if(scene.buildMode)toggleBuild(false); document.querySelectorAll('.modal').forEach(x=>x.classList.add('hidden'));}});
  addEventListener('keyup',e=>keys.delete(e.code));
  canvas.addEventListener('click',()=>{if(scene.buildMode){placeBuild();return;}if(document.getElementById('hud').classList.contains('hidden'))return;if(canvas.requestPointerLock)canvas.requestPointerLock();});
  document.addEventListener('pointerlockchange',()=>locked=document.pointerLockElement===canvas);
  addEventListener('mousemove',e=>{if(locked){mouseDX+=e.movementX;mouseDY+=e.movementY;}});

  function objectMesh(kind){return MESH[kind]||MESH.box;}
  function draw(kind,pos,scale,color,rot=[0,0,0],terrain=0){const p=[pos.x,pos.y,pos.z];const model=Mat.trs(p,rot,scale);gl.bindVertexArray(objectMesh(kind).vao);gl.uniformMatrix4fv(U.model,false,model);gl.uniform4f(U.color,color[0],color[1],color[2],color.length>3?color[3]:1);gl.uniform1i(U.terrain,terrain?1:0);gl.drawElements(gl.TRIANGLES,objectMesh(kind).count,gl.UNSIGNED_INT,0);}
  const C={ground:[.19,.37,.22],water:[.05,.28,.35,.82],wood:[.30,.18,.09],stone:[.38,.40,.36],leaf:[.12,.31,.15],leaf2:[.24,.46,.2],sand:[.55,.48,.30],ruin:[.36,.35,.30],gold:[.76,.57,.18]};

  function addTree(x,z,scale=1){scene.objects.push({kind:'tree',x,z,scale});}
  function addRock(x,z,scale=1){scene.objects.push({kind:'rock',x,z,scale});}
  function addLandmark(x,z,label){scene.objects.push({kind:'landmark',x,z,label,seen:false});}
  function generateWorld(){
    scene.objects.push({kind:'npc',x:5,z:5,name:'Rhea',title:'Field Guide',phase:0});
    for(let i=0;i<210;i++){const x=wrnd(-112,112),z=wrnd(-112,112),h=heightAt(x,z); if(h<0.7||Math.hypot(x,z)<10)continue; addTree(x,z,wrnd(.65,1.45));}
    for(let i=0;i<130;i++){const x=wrnd(-120,120),z=wrnd(-120,120),h=heightAt(x,z); if(h<.2||Math.hypot(x,z)<8)continue;addRock(x,z,wrnd(.45,1.2));}
    for(let i=0;i<18;i++){const a=i/18*TAU,r=wrnd(45,108);addLandmark(Math.cos(a)*r,Math.sin(a)*r,wpick(['Mossy Arch','Sunken Ruins','Echo Cave','Redwood Gate','Fossil Ridge','Sky Cliffs']));}
    scene.resources=[];
    const resourceTypes=['wood','stone','berries','fiber','crystal','clay','water','meat'];
    for(let i=0;i<115;i++){
      const x=wrnd(-105,105),z=wrnd(-105,105);
      if(Math.hypot(x,z)<14)continue;
      let type=wpick(resourceTypes);
      if(type==='water') z=wrnd(-98,-72);
      scene.resources.push({type,x,z,active:true,respawn:0,pulse:wrnd(0,TAU)});
    }
  }
  generateWorld();

  const dinoParts={};
  function spawnDino(type,x,z,wild=true,id=null){const s=species[type];const d={id:id||'d'+Math.random().toString(36).slice(2),type,x,y:Math.max(0.2,heightAt(x,z)),z,yaw:rnd(-Math.PI,Math.PI),state:'wander',target:null,tame:0,level:1+((Math.random()*4)|0),hp:s.hp,maxHp:s.hp,speed:s.speed,name:'Wild '+s.name,command:'follow',wild,phase:rnd(0,10),cool:rnd(0,2),baby:false,born:0,variant:Math.random(),owner:null,boss:!!s.boss,defeated:false};scene.dinos.push(d);return d;}
  const types=Object.keys(species).filter(k=>k!=='titan'); for(let i=0;i<26;i++){const type=wpick(types),a=wrnd(0,TAU),r=wrnd(34,105);spawnDino(type,Math.cos(a)*r,Math.sin(a)*r,true,'wild-'+i)}
  spawnDino('titan',72,68,true,'boss-titan').boss=true; window.__DINO_FRONTIER__.world={dinos:scene.dinos.length,trees:scene.objects.filter(o=>o.kind==='tree').length,landmarks:scene.objects.filter(o=>o.kind==='landmark').length};

  const playerMesh={x:0};
  function drawPlayer(p,isRemote=false){
    const baseY=p.y+1.15;
    const skin=isRemote?[.30,.56,.76]:[.46,.69,.50];
    const shirt=isRemote?[.10,.22,.36]:[.16,.29,.23];
    const boot=[.08,.10,.11];
    const body={x:p.x,y:baseY,z:p.z};
    draw('sphere',{x:p.x,y:p.y+.03,z:p.z},[.72,.035,.48],[.025,.035,.025],[0,0,0]);
    // torso, shoulders and neck
    draw('box',body,[.58,.82,.42],shirt,[0,p.yaw,0]);
    const neck=Mat.mulVecY({x:p.x,y:baseY+1.0,z:p.z},p.yaw,0,0);
    draw('box',neck,[.22,.20,.22],skin,[0,p.yaw,0]);
    // head + hair/helmet
    draw('sphere',{x:neck.x,y:neck.y+.38,z:neck.z},[.39,.42,.36],skin,[0,p.yaw,0]);
    const hair=Mat.mulVecY({x:p.x,y:neck.y+.66,z:p.z},p.yaw,0,-.03);
    draw('sphere',{x:hair.x,y:hair.y,z:hair.z},[.40,.18,.37],[.055,.045,.035],[0,p.yaw,0]);
    // eyes facing forward
    const face=Mat.mulVecY({x:p.x,y:neck.y+.40,z:p.z},p.yaw,.34,0);
    for(const side of [-1,1]){
      const eye=Mat.mulVecY(face,p.yaw,0,side*.13);
      draw('sphere',{x:eye.x,y:eye.y+.03,z:eye.z},[.055,.055,.035],[.96,.98,.92],[0,p.yaw,0]);
      const pupil=Mat.mulVecY(eye,p.yaw,.045,0);
      draw('sphere',{x:pupil.x,y:pupil.y,z:pupil.z},[.025,.025,.018],[.03,.04,.03],[0,p.yaw,0]);
    }
    // arms, wrists and proper hands/fingers
    const swing=Math.sin(scene.time*5.5+p.yaw)*.08;
    for(const side of [-1,1]){
      const shoulder=Mat.mulVecY(body,p.yaw,0,side*.55);
      const elbow=Mat.mulVecY({x:shoulder.x,y:shoulder.y-.36,z:shoulder.z},p.yaw,.04,side*.02);
      const hand=Mat.mulVecY({x:shoulder.x,y:shoulder.y-.72,z:shoulder.z},p.yaw,.20,side*.05);
      draw('box',shoulder,[.15,.48,.15],shirt,[swing*side,p.yaw,0]);
      draw('sphere',{x:hand.x,y:hand.y,z:hand.z},[.16,.17,.15],skin,[0,p.yaw,0]);
      for(let f=0;f<3;f++){
        const finger=Mat.mulVecY(hand,p.yaw,.13+f*.035,side*(.04-f*.035));
        draw('box',{x:finger.x,y:finger.y-.06,z:finger.z},[.035,.10,.035],skin,[0,p.yaw,0]);
      }
    }
    // legs + boots
    for(const side of [-1,1]){
      const leg=Mat.mulVecY({x:p.x,y:baseY-.85,z:p.z},p.yaw,0,side*.27);
      draw('box',leg,[.20,.68,.20],shirt,[0,p.yaw,0]);
      const boot=Mat.mulVecY({x:leg.x,y:leg.y-.45,z:leg.z},p.yaw,.10,0);
      draw('box',{x:boot.x,y:boot.y,z:boot.z},[.24,.18,.34],boot,[0,p.yaw,0]);
    }
    // survival backpack
    const pack=Mat.mulVecY(body,p.yaw,-.34,0);
    draw('box',{x:pack.x,y:pack.y+.12,z:pack.z},[.32,.52,.18],[.20,.15,.10],[0,p.yaw,0]);
    // expedition hatchet in the right hand
    const tool=Mat.mulVecY(body,p.yaw,.62,-.04);
    draw('box',{x:tool.x,y:tool.y-.12,z:tool.z},[.035,.62,.035],[.38,.22,.10],[0,p.yaw,0]);
    const blade=Mat.mulVecY({x:tool.x,y:tool.y+.22,z:tool.z},p.yaw,.02,0);
    draw('box',{x:blade.x,y:blade.y,z:blade.z},[.24,.12,.05],[.55,.61,.60],[0,p.yaw,.12]);
  }
  function drawDino(d){
    const s=species[d.type], q=s.size*(d.baby?.52:1), y=d.y+q*1.1;
    const bodyCol=s.color.map(v=>clamp(v+(d.variant-.5)*.10,0,1)); const ac=s.accent;
    const body={x:d.x,y,z:d.z};
    draw('sphere',{x:d.x,y:d.y+.035,z:d.z},[1.35*q,.035,.78*q],[.025,.035,.025],[0,0,0]);
    draw('sphere',body,[1.25*q,.72*q,.65*q],bodyCol,[0,d.yaw,0]);
    const neck=Mat.mulVecY(body,d.yaw,.52*q,0);
    draw('sphere',{x:neck.x,y:y+.22*q,z:neck.z},[.55*q,.58*q,.50*q],bodyCol,[0,d.yaw,0]);
    const head=Mat.mulVecY(body,d.yaw,.96*q,-.02*q); draw('sphere',head,[.52*q,.48*q,.48*q],bodyCol,[0,d.yaw,0]);
    const snout=Mat.mulVecY(body,d.yaw,1.32*q,-.03*q); draw('box',snout,[.46*q,.22*q,.30*q],ac,[0,d.yaw,0]);
    // eyes make creatures readable at a distance
    for(const side of [-1,1]){
      const eye=Mat.mulVecY(head,d.yaw,.32*q,side*.27*q);
      draw('sphere',{x:eye.x,y:eye.y+.12*q,z:eye.z},[.075*q,.075*q,.055*q],[.98,.90,.45],[0,d.yaw,0]);
      const pupil=Mat.mulVecY(eye,d.yaw,.045*q,0);
      draw('sphere',{x:pupil.x,y:pupil.y,z:pupil.z},[.035*q,.035*q,.025*q],[.015,.02,.015],[0,d.yaw,0]);
    }
    const swing=Math.sin(scene.time*8+d.phase)*.12;
    const legY=y-.75*q;
    for(const side of [-1,1])for(const front of [-1,1]){
      const lp=Mat.mulVecY(body,d.yaw,front*.55*q,side*.36*q);
      draw('box',{x:lp.x,y:legY,z:lp.z},[.18*q,.72*q,.18*q],bodyCol,[swing*front,d.yaw+swing*side,0]);
      const foot=Mat.mulVecY({x:lp.x,y:legY-.34*q,z:lp.z},d.yaw,.12*q,0);
      draw('box',{x:foot.x,y:foot.y,z:foot.z},[.24*q,.10*q,.32*q],ac,[0,d.yaw,0]);
    }
    const tail=Mat.mulVecY(body,d.yaw,-1.35*q,0); draw('cone',{x:tail.x,y:y+.02*q,z:tail.z},[.48*q,.58*q,.48*q],[bodyCol[0]*.9,bodyCol[1]*.9,bodyCol[2]*.9],[0,d.yaw+Math.PI/2,Math.PI/2]);
    if(d.type==='trike'){
      for(const side of [-1,1]){const horn=Mat.mulVecY(head,d.yaw,.22*q,side*.22*q);draw('cone',horn,[.11*q,.52*q,.11*q],ac,[0,d.yaw,side*.15]);}
      draw('box',Mat.mulVecY(head,d.yaw,-.20*q,0),[.46*q,.26*q,.08*q],ac,[0,d.yaw,0]);
    }
    if(d.type==='stego')for(let i=0;i<6;i++){const p=Mat.mulVecY(body,d.yaw,-.35*q-i*.27*q,0);draw('cone',{x:p.x,y:p.y+.62*q,z:p.z},[.24*q,.55*q,.16*q],ac,[0,d.yaw,0]);}
    if(d.type==='anky'){const p=Mat.mulVecY(body,d.yaw,-1.25*q,0);draw('sphere',{x:p.x,y:y-.1*q,z:p.z},[.35*q,.35*q,.35*q],ac);}
    if(d.type==='rex'){
      for(const side of [-1,1]){const arm=Mat.mulVecY(body,d.yaw,.55*q,side*.42*q);draw('box',{x:arm.x,y:y-.25*q,z:arm.z},[.10*q,.32*q,.10*q],bodyCol,[.3,d.yaw,side*.2]);}
      for(let i=0;i<5;i++){const tooth=Mat.mulVecY(snout,d.yaw,.15*q+i*.13*q,0);draw('cone',{x:tooth.x,y:y-.02*q,z:tooth.z},[.045*q,.14*q,.045*q],[.94,.88,.66],[0,d.yaw,0]);}
    }
    if(d.type==='carno')for(const side of [-1,1]){const horn=Mat.mulVecY(head,d.yaw,.02*q,side*.22*q);draw('cone',{x:horn.x,y:horn.y+.36*q,z:horn.z},[.10*q,.30*q,.10*q],ac,[0,d.yaw,0]);}
    if(d.type==='raptor')for(const side of [-1,1]){const claw=Mat.mulVecY(body,d.yaw,.58*q,side*.38*q);draw('cone',{x:claw.x,y:claw.y-.32*q,z:claw.z},[.08*q,.28*q,.08*q],ac,[Math.PI*.55,d.yaw,0]);}
    if(d.type==='ptera')for(const side of [-1,1]){const w=Mat.mulVecY(body,d.yaw,0,side*1.0*q);draw('box',{x:w.x,y:y+.15*q,z:w.z},[.85*q,.08*q,.55*q],ac,[0,d.yaw,side*.25]);}
    if(d.boss){draw('sphere',{x:d.x,y:y+1.7*q,z:d.z},[.22*q,.22*q,.22*q],ac);draw('sphere',{x:d.x,y:y+2.15*q,z:d.z},[.12*q,.12*q,.12*q],[1,.85,.25]);}
    if(!d.wild)draw('sphere',{x:d.x,y:y+1.15*q,z:d.z},[.16*q,.16*q,.16*q],[.95,.78,.24]);
    if(d.baby)draw('sphere',{x:d.x,y:y+.65*q,z:d.z},[.22*q,.22*q,.22*q],ac);
  }

  function resourceObject(r){
    if(!r.active)return;
    const y=heightAt(r.x,r.z), bob=Math.sin(scene.time*2+r.pulse)*.08;
    if(r.type==='wood'){
      draw('box',{x:r.x,y:y+.45+bob,z:r.z},[.28,.75,.28],C.wood,[.2,r.pulse,0]);
      draw('box',{x:r.x+.18,y:y+.95+bob,z:r.z+.08},[.20,.20,.20],[.48,.29,.12],[0,r.pulse,.2]);
    } else if(r.type==='stone'){
      draw('sphere',{x:r.x,y:y+.48+bob,z:r.z},[.62,.48,.58],C.stone,[0,r.pulse,0]);
      draw('cone',{x:r.x+.2,y:y+.85+bob,z:r.z},[.20,.34,.20],[.55,.57,.54]);
    } else if(r.type==='berries'){
      draw('sphere',{x:r.x,y:y+.55+bob,z:r.z},[.72,.48,.72],C.leaf2);
      for(let i=0;i<5;i++){const a=i/5*TAU;draw('sphere',{x:r.x+Math.cos(a)*.35,y:y+.60+bob+Math.sin(i)*.08,z:r.z+Math.sin(a)*.35},[.09,.09,.09],[.76,.16,.24]);}
    } else if(r.type==='fiber'){
      for(let i=0;i<6;i++){const a=i/6*TAU;draw('box',{x:r.x+Math.cos(a)*.20,y:y+.42+bob,z:r.z+Math.sin(a)*.20},[.05,.55,.05],[.20,.58,.24],[Math.sin(a)*.35,a,0]);}
    } else if(r.type==='crystal'){
      for(let i=0;i<3;i++){const a=i*2.1;draw('cone',{x:r.x+Math.cos(a)*.22,y:y+.55+bob,z:r.z+Math.sin(a)*.22},[.18,.55,.18],[.30,.72,.78],[0,a,0]);}
    } else if(r.type==='clay'){
      draw('sphere',{x:r.x,y:y+.32+bob,z:r.z},[.62,.32,.55],[.48,.29,.20]);
    } else if(r.type==='meat'){
      draw('sphere',{x:r.x,y:y+.20+bob,z:r.z},[.48,.20,.34],[.60,.18,.15]);
      draw('sphere',{x:r.x+.22,y:y+.22+bob,z:r.z+.12},[.13,.08,.13],[.82,.68,.55]);
    } else {
      draw('box',{x:r.x,y:y+.12+bob,z:r.z},[.58,.08,.58],[.18,.45,.55]);
      draw('sphere',{x:r.x,y:y+.25+bob,z:r.z},[.18,.10,.18],[.30,.72,.82]);
    }
  }

  function drawBuild(b){
    const y=heightAt(b.x,b.z); if(b.type==='hut'){draw('box',{x:b.x,y:y+1.2,z:b.z},[2.6,1.2,2.6],C.wood);draw('box',{x:b.x,y:y+2.8,z:b.z},[2.9,.18,2.9],[.22,.12,.07],[0,Math.PI/4,0])}
    if(b.type==='fence'){draw('box',{x:b.x,y:y+1,z:b.z},[1.8,1,.15],C.wood)}
    if(b.type==='garden'){draw('box',{x:b.x,y:y+.08,z:b.z},[1.7,.12,1.7],[.20,.11,.06]);draw('box',{x:b.x,y:y+.14,z:b.z},[1.45,.03,1.45],[.35,.25,.12])}
    if(b.type==='storage'){draw('box',{x:b.x,y:y+.55,z:b.z},[.9,.55,.75],C.wood);draw('box',{x:b.x,y:y+1.1,z:b.z},[.82,.05,.72],[.45,.28,.12])}
  }

  function zoneName(x,z){if(Math.hypot(x,z)<22)return 'Verdant Basin';if(z<-55)return 'Amber Coast';if(x>55)return 'Redwood Expanse';if(x<-60)return 'Stoneback Mesa';if(z>60)return 'Frostwild Ridge';return 'Fernwood Frontier'}

  function createWorldGeometry(){
    scene.objects.forEach(o=>{});
  }
  createWorldGeometry();

  // ---------- UI ----------
  const $=id=>document.getElementById(id);
  function showNotice(msg){sfx(320,.06);const n=document.createElement('div');n.className='notice';n.textContent=msg;$('notices').appendChild(n);setTimeout(()=>n.remove(),4200)}
  function updateStats(){
    $('hpBar').style.width=clamp(player.hp/player.maxHp*100,0,100)+'%'; $('stBar').style.width=player.st+'%';$('foodBar').style.width=player.hunger+'%';$('waterBar').style.width=player.thirst+'%';$('tempBar').style.width=player.temp+'%';$('hpTxt').textContent=Math.max(0,player.hp|0);$('level').textContent='LV '+player.level; $('zone').textContent=zoneName(player.x,player.z);
    const q=questList[questIndex],v=clamp(q.get(),0,q.target);$('questTitle').textContent=q.title;$('questDesc').textContent=q.desc;$('questBar').style.width=(v/q.target*100)+'%';$('questCount').textContent=v+' / '+q.target;
  }
  function updateHotbar(){const items=[['BR','Berries','berries'],['WD','Wood','wood'],['ST','Stone','stone'],['FI','Fiber','fiber'],['CR','Crystal','crystal'],['CL','Clay','clay'],['H2O','Water','water'],['SE','Seeds','seeds'],['PR','Meat','meat']];$('hotbar').innerHTML=items.map((a,i)=>`<div class="slot ${i===0?'sel':''}"><small>${i+1}</small><span style="font:900 10px system-ui;color:#b9f27c">${a[0]}</span><b>${player[a[2]]||0}</b></div>`).join('')}
  function updateInventory(){const items=[['Wood',player.wood],['Stone',player.stone],['Berries',player.berries],['Fiber',player.fiber],['Crystal',player.crystal],['Clay',player.clay],['Water',player.water],['Seeds',player.seeds],['Meat',player.meat],['Fish',player.fish],['Shelter pieces',player.builds],['Level',player.level]];$('inventoryGrid').innerHTML=items.map(x=>`<div class="item"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('');const crafts=[['Campfire',8,0,0],['Saddle',25,15,0],['Fence bundle',10,3,0],['Garden',7,0,2],['Explorer Kit',18,8,2],['Crystal Beacon',12,6,3]];$('craftGrid').innerHTML=crafts.map((c,i)=>`<div class="craft"><b>${c[0]}</b><span>${c[1]} wood${c[2]?` + ${c[2]} stone`:''}${c[3]?` + ${c[3]} fiber`:''}</span><button data-craft="${i}">CRAFT</button></div>`).join('');$('craftGrid').querySelectorAll('button').forEach(b=>b.onclick=()=>craft(+b.dataset.craft));}
  function toggleModal(id){const e=$(id);e.classList.toggle('hidden');if(id==='invModal')updateInventory();if(id==='mapModal')drawMap()}
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>$(b.dataset.close).classList.add('hidden'));
  $('mapBtn').onclick=()=>toggleModal('mapModal');$('invBtn').onclick=()=>toggleModal('invModal');$('saveBtn').onclick=()=>{saveGame();showNotice('Progress saved to this browser.')};
  function toggleBuild(v){scene.buildMode=v===undefined?!scene.buildMode:v;$('buildHud').classList.toggle('hidden',!scene.buildMode);updateBuildHUD()}
  function updateBuildHUD(){const names=['HUT','FENCE','GARDEN','STORAGE'];$('buildChoice').textContent=names[scene.buildChoice]||'HUT'}
  function craft(i){
    const recipes=[
      ['Campfire',8,0,0],['Saddle',25,15,0],['Fence bundle',10,3,0],['Garden',7,0,2],['Explorer Kit',18,8,2],['Crystal Beacon',12,6,3]
    ];
    const r=recipes[i];if(!r)return;
    if(player.wood<r[1]||player.stone<r[2]||player.fiber<r[3]){showNotice('Not enough materials.');return}
    player.wood-=r[1];player.stone-=r[2];player.fiber-=r[3];
    if(i===0)player.food+=1;
    if(i===1)showNotice(player.tames.length?'Saddle crafted — your mounts can travel farther.':'Saddle crafted — tame a rideable dinosaur first.');
    if(i===2)player.builds+=2;
    if(i===3)player.seeds+=2;
    if(i===4){player.maxHp+=5;player.st+=15;showNotice('Explorer Kit crafted: tougher and faster expeditions.')}
    if(i===5){player.discoveries['Crystal Beacon']=1;gainXP(20);showNotice('Crystal Beacon crafted. Ancient routes now glow on your map.')}
    showNotice(r[0]+' crafted.');updateInventory();updateHotbar();
  }
  function saveGame(){const data={player:{...player,tames:player.tames.map(d=>({...d}))},builds:scene.builds,farms:scene.farms,questIndex};localStorage.setItem('dinoFrontier3D',JSON.stringify(data));}
  function loadGame(){try{const s=JSON.parse(localStorage.getItem('dinoFrontier3D')||'null');if(!s)return;Object.assign(player,s.player||{});questIndex=clamp(s.questIndex||0,0,questList.length-1);scene.builds=s.builds||[];scene.farms=s.farms||[];if(Array.isArray(player.tames)){player.tames.forEach(t=>{t.wild=false;scene.dinos.push(t)})}showNotice('Welcome back, '+player.name+'.');}catch(e){console.warn(e)}}

  // ---------- Interaction / gameplay ----------
  function nearest(){let best=null,bd=64;for(const d of scene.dinos){const dd=Math.hypot(player.x-d.x,player.z-d.z);if(dd<bd){bd=dd;best={kind:'dino',obj:d,dist:dd}}}for(const r of scene.resources){if(!r.active)continue;const dd=Math.hypot(player.x-r.x,player.z-r.z);if(dd<bd){bd=dd;best={kind:'resource',obj:r,dist:dd}}}for(const f of scene.farms){const dd=Math.hypot(player.x-f.x,player.z-f.z);if(dd<bd){bd=dd;best={kind:'farm',obj:f,dist:dd}}}for(const o of scene.objects){
      if(o.kind==='npc'){const dd=Math.hypot(player.x-o.x,player.z-o.z);if(dd<bd){bd=dd;best={kind:'npc',obj:o,dist:dd}}}
      if((o.kind==='tree'||o.kind==='rock')&&Math.hypot(player.x-o.x,player.z-o.z)<3.2){const dd=Math.hypot(player.x-o.x,player.z-o.z);if(dd<bd){bd=dd;best={kind:'sceneryResource',obj:o,dist:dd}}}
    }return best}
  function interact(){const n=nearest();if(!n){showNotice('Nothing close enough to interact with.');return}
    if(n.kind==='resource') gather(n.obj); else if(n.kind==='sceneryResource') gatherScenery(n.obj); else if(n.kind==='dino') interactDino(n.obj); else if(n.kind==='farm') interactFarm(n.obj); else if(n.kind==='npc') npcTalk(n.obj);
  }
  function npcTalk(npc){const q=questList[questIndex];showNotice(npc.name+": Keep an eye on the ridgelines. There is an ancient camp north of here.");if(q.get()>=q.target){questUpdate()}else showNotice('Field log: '+q.title+' — '+q.desc);}

  addEventListener('keydown',e=>{if(e.repeat)return;if(e.code==='KeyE')interact();if(e.code==='KeyF'&&scene.mounted)feedMounted();if(e.code==='KeyH'&&scene.mounted)commandMounted('harvest');if(e.code==='KeyT')showTutorial(true);});
  function gather(r){if(!r.active)return;r.active=false;r.respawn=scene.time+18;if(r.type==='wood'){player.wood+=3;player.fiber+=1;gainXP(3)}else if(r.type==='stone'){player.stone+=3;player.clay+=1;gainXP(3)}else if(r.type==='berries'){player.berries+=4;gainXP(2)}else if(r.type==='fiber'){player.fiber+=3;gainXP(2)}else if(r.type==='crystal'){player.crystal+=1;gainXP(5)}else if(r.type==='clay'){player.clay+=3;gainXP(2)}else if(r.type==='meat'){player.meat+=2;gainXP(3)}else {player.water=Math.min(12,player.water+3);player.fish+=1;gainXP(2)};showNotice('Gathered '+r.type+'.');updateHotbar()} 
  function gatherScenery(o){if(o.gatheredUntil&&scene.time<o.gatheredUntil){showNotice('This resource needs time to regrow.');return}o.gatheredUntil=scene.time+8;if(o.kind==='tree'){player.wood+=3;player.fiber+=1;gainXP(3);showNotice('You harvest the tree: +3 wood, +1 fiber.')}else{player.stone+=3;player.clay+=1;gainXP(3);showNotice('You mine the rock: +3 stone, +1 clay.')}updateHotbar()}
  function interactFarm(f){if(f.grown){f.grown=false;f.harvests++;player.berries+=5;player.seeds+=2;gainXP(8);showNotice('Garden harvested: berries +5, seeds +2.');sendMutation({kind:'farm',farm:f})}else if(!f.planted){if(player.seeds<=0){showNotice('You need seeds.');return}f.planted=true;f.grow=scene.time+18;showNotice('Garden planted.');sendMutation({kind:'farm',farm:f})}else showNotice('The crop is growing.');}
  function interactDino(d){scene.selected=d;$('dinoCard').classList.remove('hidden');updateDinoCard();const s=species[d.type];if(d.boss){showNotice('ELDER TITAN • Command a strong companion squad to calm it.');return}if(d.wild&&s.diet!=='PREDATOR')tame(d);else if(d.wild&&s.diet==='PREDATOR'){if(player.meat>0&&d.tame>=s.tame*.25){player.meat--;d.tame+=1;showNotice('You offer food to '+s.name+'. Trust '+Math.round(d.tame/s.tame*100)+'%.')}else showNotice('That predator keeps its distance. Track it and learn its behavior first.')} }
  function tame(d){const s=species[d.type];if(player.berries<=0){showNotice('You need berries.');return}player.berries--;d.tame++;const pct=d.tame/s.tame;if(pct>=1){d.wild=false;d.owner=player.name;d.name=s.name+' Companion';d.level=Math.max(2,d.level);if(!player.tames.some(x=>x.id===d.id))player.tames.push(d);player.xp+=35;showNotice('Tamed! '+d.name+' is now part of your expedition.');if(net.peer&&!net.host){const c=net.connections.get('host');if(c?.open)c.send({t:'tameRequest',dinoId:d.id,owner:player.name})}else if(net.host)broadcastWorld();}else showNotice('Trust increased to '+Math.round(pct*100)+'%. Stay calm and keep feeding.');updateDinoCard();updateHotbar();}
  function updateDinoCard(){const d=scene.selected;if(!d){$('dinoCard').classList.add('hidden');return}const s=species[d.type];$('dinoName').textContent=d.name;$('dinoSpecies').textContent=s.name+' • '+s.diet;$('dinoTameBar').style.width=(d.wild?clamp(d.tame/s.tame*100,0,100):100)+'%';$('dinoMeta').textContent=d.wild?Math.round(d.tame/s.tame*100)+'% trust':'Level '+d.level+' • '+d.command;$('tameBtn').textContent=d.wild?'FEED':'FEED';$('rideBtn').textContent=scene.mounted===d?'DISMOUNT':'RIDE';$('commandBtn').textContent='COMMAND'}
  function showTutorial(force=false){const el=$('tutorialModal');if(!el)return;if(force||localStorage.getItem('dinoFrontierTutorialSeen')!=='1'){el.classList.remove('hidden');localStorage.setItem('dinoFrontierTutorialSeen','1')}}
  $('tutorialBtn').onclick=()=>showTutorial(true);
  document.querySelectorAll('[data-tutorial-close]').forEach(b=>b.addEventListener('click',()=>document.getElementById('tutorialModal').classList.add('hidden')));

  $('tameBtn').onclick=()=>{if(scene.selected)interactDino(scene.selected)};$('rideBtn').onclick=()=>{if(scene.selected&&!scene.selected.wild)toggleRide(scene.selected)};$('commandBtn').onclick=()=>commandMounted();$('nameBtn').onclick=()=>{if(!scene.selected||scene.selected.wild)return;const n=prompt('Name your companion',scene.selected.name||species[scene.selected.type].name);if(n&&n.trim()){scene.selected.name=n.trim().slice(0,20);showNotice('Companion renamed to '+scene.selected.name);sendMutation({kind:'tamed',dino:netDino(scene.selected)})}};
  function netDino(d){return {id:d.id,type:d.type,x:d.x,y:d.y,z:d.z,yaw:d.yaw,tame:d.tame,level:d.level,hp:d.hp,maxHp:d.maxHp,speed:d.speed,name:d.name,command:d.command,wild:d.wild,baby:d.baby,born:d.born,variant:d.variant,owner:d.owner,boss:d.boss}}
  function breedNearby(){const a=player.tames.find(d=>!d.baby&&Math.hypot(d.x-player.x,d.z-player.z)<7);if(!a){showNotice('Bring a tamed dinosaur close.');return}const b=player.tames.find(d=>d!==a&&!d.baby&&d.type===a.type&&Math.hypot(d.x-a.x,d.z-a.z)<7);if(!b){showNotice('You need two compatible companions of the same species nearby.');return}if(net.peer&&!net.host){const ids=[a.id,b.id].sort();const msg={t:'breedRequest',a:ids[0],b:ids[1],owner:player.name};for(const c of net.connections.values())if(c.open)c.send(msg);showNotice('Breeding request sent to the world host.');return}createBaby(a,b,player.name)}
  function createBaby(a,b,owner){const s=species[a.type],id='baby-'+a.id+'-'+b.id+'-'+Math.floor(scene.time*10),baby=spawnDino(a.type,(a.x+b.x)/2,(a.z+b.z)/2,false,id);baby.wild=false;baby.baby=true;baby.born=scene.time;baby.name='Baby '+s.name;baby.owner=owner;baby.level=1;baby.hp=baby.maxHp*=.55;baby.speed*=.55;baby.variant=Math.random()*.6+.2;if(!player.tames.some(x=>x.id===baby.id)&&owner===player.name)player.tames.push(baby);showNotice('A baby '+s.name+' joined the nursery!');sendMutation({kind:'breed',dino:netDino(baby)})}
  addEventListener('keydown',e=>{if(!e.repeat&&e.code==='KeyN')breedNearby()});
  function rideNearest(){const d=scene.selected&&!scene.selected.wild?scene.selected:scene.dinos.filter(x=>!x.wild).sort((a,b)=>dist2(a,player)-dist2(b,player))[0];if(d&&Math.sqrt(dist2(d,player))<8)toggleRide(d);else showNotice('Bring a tamed rideable dinosaur close.')}
  function toggleRide(d){const s=species[d.type];if(!s.ride){showNotice('This creature is a companion, not a mount.');return}if(scene.mounted===d){scene.mounted=null;player.x=d.x+1;player.z=d.z+1;showNotice('Dismounted.')}else{scene.mounted=d;showNotice('Mounted '+d.name+'. Use WASD to travel.')}updateDinoCard()}
  function feedMounted(){if(!scene.mounted||player.berries<=0)return;player.berries--;scene.mounted.hp=Math.min(scene.mounted.maxHp,scene.mounted.hp+25);scene.mounted.tame=Math.max(scene.mounted.tame,999);showNotice(scene.mounted.name+' enjoys the snack.')} 
  function commandMounted(cmd){const cycle=['follow','stay','guard','attack'];if(!scene.mounted){if(scene.selected&&!scene.selected.wild){const i=Math.max(0,cycle.indexOf(scene.selected.command));scene.selected.command=cmd||cycle[(i+1)%cycle.length];showNotice(scene.selected.name+' is set to '+scene.selected.command+'.')}else showNotice('Tame a dinosaur first.');return}const i=Math.max(0,cycle.indexOf(scene.mounted.command));scene.mounted.command=cmd||cycle[(i+1)%cycle.length];showNotice(scene.mounted.name+' command: '+scene.mounted.command);updateDinoCard();sendMutation({kind:'tamed',dino:netDino(scene.mounted)})}
  function gainXP(n){player.xp+=n;const need=100+player.level*55;if(player.xp>=need){player.xp-=need;player.level++;player.maxHp+=8;player.hp=player.maxHp;showNotice('LEVEL UP! You are now level '+player.level+'.')}}

  function placeBuild(){if(!scene.buildMode)return;const yaw=player.yaw;const p=Mat.mulVecY({x:player.x,y:0,z:player.z},yaw,0,-4);const qx=Math.round(p.x/1.8)*1.8,qz=Math.round(p.z/1.8)*1.8;const names=['hut','fence','garden','storage'];const type=names[scene.buildChoice];const cost={hut:[18,6],fence:[6,1],garden:[7,0],storage:[10,3]}[type];if(player.wood<cost[0]||player.stone<cost[1]){showNotice('Not enough resources for '+type+'.');return}player.wood-=cost[0];player.stone-=cost[1];const b={id:'b'+Math.random().toString(36).slice(2),type,x:qx,z:qz,owner:player.name};scene.builds.push(b);if(type==='garden')scene.farms.push({id:'f'+b.id,x:qx,z:qz,planted:false,grown:false,grow:0,harvests:0});sendMutation({kind:'build',build:b,farms:scene.farms});showNotice(type.toUpperCase()+' placed.');gainXP(5);updateHotbar()}

  // ---------- Dino AI ----------
  function nearestPlayerLike(d){let best={x:player.x,z:player.z,dist:Math.hypot(player.x-d.x,player.z-d.z),real:true};for(const r of scene.remotes.values()){const dd=Math.hypot(r.x-d.x,r.z-d.z);if(dd<best.dist)best={x:r.x,z:r.z,dist:dd,real:false}}return best}
  function updateDinos(dt){
    for(const d of scene.dinos){const s=species[d.type];d.cool-=dt;
      if(d.baby){if(scene.time-d.born>35){d.baby=false;d.level=2;d.speed*=1.45;d.maxHp*=1.5;d.hp=d.maxHp;showNotice(d.name+' grew into a juvenile.')}}
      if(scene.mounted===d){d.x=player.x;d.z=player.z;d.y=heightAt(d.x,d.z);d.yaw=player.yaw;continue}
      const target=nearestPlayerLike(d);
      if(d.wild){
        if(s.diet==='PREDATOR'&&target.dist<s.aggro){d.state='chase';d.target=target}
        else if(s.diet!=='PREDATOR'&&target.dist<8){d.state='flee';d.target=target}
        else if(d.state==='chase'&&target.dist>s.aggro*1.5)d.state='wander';
        else if(d.state==='flee'&&target.dist>18)d.state='wander';
      }else if(d.command==='follow'&&target.dist>6){d.state='follow';d.target={x:player.x,z:player.z}}
      else if(d.command==='stay'){d.state='stay'}
      else if(d.command==='guard'){d.state='guard'}
      else d.state='wander';
      let mx=0,mz=0,spd=s.speed*(d.baby?.45:1);
      if(d.state==='chase'&&d.target){mx=d.target.x-d.x;mz=d.target.z-d.z;spd*=1.18}
      else if(d.state==='flee'&&d.target){mx=d.x-d.target.x;mz=d.z-d.target.z}
      else if(d.state==='follow'&&d.target){mx=d.target.x-d.x;mz=d.target.z-d.z;spd*=.9}
      else if(d.state==='wander'){mx=Math.cos(d.phase+scene.time*.12);mz=Math.sin(d.phase*1.7+scene.time*.09)}
      if(d.state!=='stay'){const l=Math.hypot(mx,mz)||1;d.yaw=Math.atan2(mx,mz);d.x+=mx/l*spd*dt;d.z+=mz/l*spd*dt;d.x=clamp(d.x,-118,118);d.z=clamp(d.z,-118,118)}
      d.y=heightAt(d.x,d.z); if(s.fly)d.y=5.5+Math.sin(scene.time*.8+d.phase)*2.2;
      // Friendly early-game predator combat: telegraphed hits, reduced damage, and a short invulnerability window.
      if(player.damageCooldown>0)player.damageCooldown-=dt;
      const safeZone=Math.hypot(player.x,player.z)<16;
      if(s.diet==='PREDATOR'&&target.real&&target.dist<1.7&&!safeZone&&d.cool<=0&&player.damageCooldown<=0){d.cool=1.25;player.damageCooldown=1.0;const dmg=d.boss?6:(s.name==='Tyrannosaur'?7:5);player.hp-=dmg;showNotice((d.boss?'The Elder Titan ':'A '+s.name+' ')+(d.boss?'shakes the ground!':'strikes! Get away or use a mount.'));}
      if(!d.wild&&d.command==='attack'){const enemy=scene.dinos.find(x=>x.wild&&x!==d&&!x.defeated&&Math.hypot(x.x-d.x,x.z-d.z)<6&&(x.boss||species[x.type].diet==='PREDATOR'));if(enemy&&d.cool<=0){enemy.hp-=18;d.cool=1.0;if(enemy.hp<=0){enemy.defeated=true;if(enemy.boss){showNotice('ELDER TITAN DEFEATED! Your expedition has mastered the ridge.');gainXP(160)}else{enemy.wild=false;enemy.name='Calmed '+species[enemy.type].name;enemy.owner=player.name;showNotice(enemy.name+' backed down.');}}}}
    }
  }

  // ---------- Survival, farm, quests ----------
  function updateSurvival(dt){if(scene.mounted)return;player.st=Math.min(100,player.st+dt*12);player.hunger=Math.max(0,player.hunger-dt*.18);player.thirst=Math.max(0,player.thirst-dt*.25);player.temp=clamp(50 + (heightAt(player.x,player.z)-8)*2 + Math.sin(scene.day*TAU)*7,0,100);if(player.hunger<10||player.thirst<10)player.hp-=dt*1.7;if(player.hp<=0)respawn()}
  function respawn(){player.hp=player.maxHp;player.hunger=70;player.thirst=70;player.x=0;player.z=4;player.y=heightAt(0,4);player.vy=0;scene.mounted=null;showNotice('You wake at your camp. Keep exploring!')}
  function updateFarms(){for(const f of scene.farms){if(f.planted&&!f.grown&&scene.time>=f.grow){f.grown=true;sendMutation({kind:'farm',farm:f})}}}
  let expeditionComplete=false;
  function questUpdate(){const q=questList[questIndex];if(q.get()>=q.target){if(questIndex<questList.length-1){showNotice('Quest complete: '+q.title);questIndex++;gainXP(30);if(questList[questIndex].id==='friend')player.seeds+=5}else if(!expeditionComplete){expeditionComplete=true;showNotice('Expedition complete! The valley is yours to master.');gainXP(80)}}}

  // ---------- Camera / movement ----------
  function updatePlayer(dt){
    if(scene.mounted){player.x=scene.mounted.x;player.z=scene.mounted.z;player.y=scene.mounted.y;return}
    mouseDX*=.72;mouseDY*=.72;scene.camera.yaw-=mouseDX*.0025;scene.camera.pitch=clamp(scene.camera.pitch-mouseDY*.0025,-.85,.22);mouseDX=mouseDY=0;
    let f=(keys.has('KeyW')?1:0)-(keys.has('KeyS')?1:0),r=(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0);const l=Math.hypot(f,r)||1;f/=l;r/=l;const sprint=keys.has('ShiftLeft')||keys.has('ShiftRight');let speed=sprint&&player.st>1?8.4:4.8;if(sprint&&l>0)player.st-=dt*18;
    const fw={x:Math.sin(scene.camera.yaw),z:Math.cos(scene.camera.yaw)},rt={x:Math.cos(scene.camera.yaw),z:-Math.sin(scene.camera.yaw)};let vx=(fw.x*f+rt.x*r)*speed,vz=(fw.z*f+rt.z*r)*speed;if(l>0)player.yaw=lerp(player.yaw,Math.atan2(vx,vz),clamp(dt*10,0,1));
    player.x=clamp(player.x+vx*dt,-119,119);player.z=clamp(player.z+vz*dt,-119,119);player.vy-=22*dt;player.y+=player.vy*dt;const g=heightAt(player.x,player.z);if(player.y<g){player.y=g;player.vy=0}if(keys.has('Space')&&Math.abs(player.vy)<.05){player.vy=8.2;keys.delete('Space')}
    if(scene.buildMode&&l>0){/* build mode intentionally keeps movement */}
  }
  function updateCamera(){const p={x:player.x,y:player.y+1.6,z:player.z};let d=scene.mounted?10:scene.camera.dist;const back={x:Math.sin(scene.camera.yaw)*Math.cos(scene.camera.pitch),y:Math.sin(scene.camera.pitch),z:Math.cos(scene.camera.yaw)*Math.cos(scene.camera.pitch)};const eye=[p.x-back.x*d,p.y-back.y*d+1.5,p.z-back.z*d];const center=[p.x,p.y+0.25,p.z];return {eye,center}}

  function drawSky(){
    const day=Math.max(0,Math.sin(scene.day*TAU));const sky=[.035+.12*day,.065+.22*day,.09+.2*day];gl.clearColor(sky[0],sky[1],sky[2],1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  }

  function render(){resize();drawSky();const cam=updateCamera();const proj=Mat.perspective(Math.PI/3,canvas.width/canvas.height,.1,320);const view=Mat.look(cam.eye,cam.center);gl.uniformMatrix4fv(U.proj,false,proj);gl.uniformMatrix4fv(U.view,false,view);const sunAng=scene.day*TAU;gl.uniform3f(U.sun,Math.cos(sunAng)*.5,.85,Math.sin(sunAng)*.5);const fogcol=scene.rain>.5?[.18,.23,.24]:[.09,.16,.14];gl.uniform3f(U.fog,...fogcol);gl.uniform1f(U.fogNear,45);gl.uniform1f(U.fogFar,220);
    draw('terrain',{x:0,y:0,z:0},[1,1,1],[1,1,1],[],1);
    // Solid fallback floor beneath the procedural terrain so the world never looks or feels bottomless.
    draw('box',{x:0,y:-.32,z:0},[126,.32,126],[.11,.20,.13]);
    // water + shallow coast
    draw('box',{x:0,y:-.15,z:-12},[125,.12,125],C.water);
    // natural objects cull by distance
    for(const o of scene.objects){const dd=Math.hypot(o.x-player.x,o.z-player.z);if(dd>150)continue;const y=heightAt(o.x,o.z);if(o.kind==='tree'){draw('box',{x:o.x,y:y+1.9*o.scale,z:o.z},[.25*o.scale,1.9*o.scale,.25*o.scale],C.wood);draw('sphere',{x:o.x,y:y+4.0*o.scale,z:o.z},[1.8*o.scale,2.0*o.scale,1.8*o.scale],C.leaf,[0,0,0]);draw('sphere',{x:o.x+.8*o.scale,y:y+3.4*o.scale,z:o.z+.4*o.scale},[1.2*o.scale,1.4*o.scale,1.2*o.scale],C.leaf2)}else if(o.kind==='rock'){draw('sphere',{x:o.x,y:y+.35*o.scale,z:o.z},[.9*o.scale,.6*o.scale,.75*o.scale],C.stone,[0,o.x,0])}else if(o.kind==='landmark'){draw('box',{x:o.x,y:y+2.8,z:o.z},[3.0,.35,3.0],C.ruin);draw('box',{x:o.x-2.0,y:y+1.5,z:o.z},[.35,1.6,.35],C.ruin);draw('box',{x:o.x+2.0,y:y+1.5,z:o.z},[.35,1.6,.35],C.ruin);if(Math.hypot(o.x-player.x,o.z-player.z)<8&&!o.seen){o.seen=true;player.discoveries[o.label]=1;gainXP(12);showNotice('DISCOVERY: '+o.label)}}}
    for(const r of scene.resources)if(r.active&&Math.hypot(r.x-player.x,r.z-player.z)<150)resourceObject(r);
    for(const b of scene.builds)drawBuild(b);
    for(const f of scene.farms){const y=heightAt(f.x,f.z);draw('box',{x:f.x,y:y+.06,z:f.z},[1.75,.06,1.75],[.24,.14,.07]);if(f.planted)for(let k=0;k<5;k++){const px=f.x-1+k*.5,pz=f.z+(k%2?-.4:.35);draw('box',{x:px,y:y+.22,z:pz},[.06,.3,.06],f.grown?[.72,.54,.18]:[.25,.5,.22]);}}
    for(const d of scene.dinos){if(Math.hypot(d.x-player.x,d.z-player.z)<150)drawDino(d)}
    drawPlayer(player); for(const r of scene.remotes.values()){if(Math.hypot(r.x-player.x,r.z-player.z)<150)drawPlayer(r,true)}
    // crosshair
    gl.flush();
    drawMiniMap();
  }

  function drawMiniMap(){const c=$('minimap'),ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#0b201a';ctx.fillRect(0,0,w,h);ctx.globalAlpha=.5;ctx.strokeStyle='#427768';for(let i=0;i<7;i++){ctx.beginPath();ctx.arc(w/2,h/2,25+i*11,0,TAU);ctx.stroke()}ctx.globalAlpha=1;const sx=w/240,sy=h/240;for(const d of scene.dinos){const x=w/2+d.x*sx,y=h/2+d.z*sy;ctx.fillStyle=species[d.type].diet==='PREDATOR'?'#e87862':'#87c88b';ctx.fillRect(x-2,y-2,4,4)}for(const r of scene.resources){if(r.active){ctx.fillStyle='#c5a65b';ctx.fillRect(w/2+r.x*sx-1,h/2+r.z*sy-1,2,2)}}ctx.fillStyle='#eaf7dc';ctx.beginPath();ctx.arc(w/2+player.x*sx,h/2+player.z*sy,4,0,TAU);ctx.fill();ctx.fillStyle='#79d9c2';ctx.font='9px system-ui';ctx.fillText('N',w-14,12)}
  function drawMap(){const c=$('mapCanvas'),ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.fillStyle='#10241f';ctx.fillRect(0,0,w,h);ctx.fillStyle='#214c3c';ctx.fillRect(22,20,w-44,h-40);ctx.globalAlpha=.45;for(let i=0;i<12;i++){ctx.fillStyle=i%2?'#305d42':'#2b543a';ctx.beginPath();ctx.arc(rnd(50,w-50),rnd(50,h-50),rnd(12,38),0,TAU);ctx.fill()}ctx.globalAlpha=1;for(const o of scene.objects)if(o.kind==='landmark'){const x=w/2+o.x/250*w,y=h/2+o.z/250*h;ctx.fillStyle='#dbb85b';ctx.fillRect(x-3,y-3,6,6)}ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(w/2+player.x/250*w,h/2+player.z/250*h,6,0,TAU);ctx.fill();ctx.fillStyle='#cedbd4';ctx.font='14px system-ui';ctx.fillText('Explore the frontier • landmarks reveal as you approach',22,h-18)}

  // ---------- multiplayer ----------
  const net={peer:null,host:false,room:'',connections:new Map(),status:'solo',lastSend:0,lastWorld:0};
  function randomRoom(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<6;i++)s+=chars[(Math.random()*chars.length)|0];return 'DF-'+s}
  function setNetStatus(t){$('netStatus').textContent=t}
  let peerLoading=null;
  function ensurePeer(ready){if(typeof Peer!=='undefined'){ready();return}if(peerLoading){peerLoading.then(ready);return}peerLoading=new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/peerjs@1.5.5/dist/peerjs.min.js';s.async=true;s.onload=()=>resolve();s.onerror=()=>reject(new Error('PeerJS failed to load'));document.head.appendChild(s)});peerLoading.then(ready).catch(()=>setNetStatus('Multiplayer could not load. Solo mode is still available.'))}
  function setupHost(){if(typeof Peer==='undefined'){setNetStatus('Loading multiplayer…');ensurePeer(setupHost);return}net.host=true;net.room=randomRoom();$('room').value=net.room;net.peer=new Peer('dino-frontier-'+net.room);net.peer.on('open',()=>{setNetStatus('WORLD LIVE • Share room code '+net.room);startGame();});net.peer.on('connection',c=>{net.connections.set(c.peer,c);wireConn(c);broadcastWorld();updatePlayersUI()});net.peer.on('error',e=>{setNetStatus('Network error: '+(e.type||'unknown')+'. Try another room.');console.warn(e)})}
  function setupJoin(code){if(typeof Peer==='undefined'){setNetStatus('Loading multiplayer…');ensurePeer(()=>setupJoin(code));return}net.host=false;net.room=code.trim().toUpperCase();if(!net.room)return setNetStatus('Enter the host room code.');net.peer=new Peer();net.peer.on('open',()=>{const c=net.peer.connect('dino-frontier-'+net.room,{reliable:true});net.connections.set('host',c);wireConn(c);setNetStatus('Connecting to '+net.room+'…')});net.peer.on('error',e=>{setNetStatus('Could not join: '+(e.type||'network error'));console.warn(e)})}
  function wireConn(c){c.on('open',()=>{c.send({t:'hello',name:player.name});setNetStatus('CONNECTED • P2P co-op live');startGame()});c.on('data',msg=>handleNet(msg,c));c.on('close',()=>{net.connections.delete(c.peer);scene.remotes.delete(c.peer);updatePlayersUI()});c.on('error',console.warn)}
  function broadcastWorld(){if(!net.host)return;const dinos=scene.dinos.filter(d=>!d.wild||d.boss).map(netDino);const pack={t:'world',builds:scene.builds,farms:scene.farms,dinos};for(const c of net.connections.values())if(c.open)c.send(pack)}
  function sendMutation(m){if(!net.peer)return;if(net.host){applyMutation(m,player.name);broadcastWorld();return}const hostConn=net.connections.get('host');if(hostConn?.open)hostConn.send({t:'mutation',...m,owner:player.name})}
  function applyMutation(m,owner){if(m.kind==='build'&&m.build&&!scene.builds.some(b=>b.id===m.build.id))scene.builds.push(m.build);if(m.kind==='farm'&&m.farm){const i=scene.farms.findIndex(f=>f.id===m.farm.id);if(i<0)scene.farms.push(m.farm);else scene.farms[i]=m.farm}if(m.kind==='tamed'&&m.dino){const d=scene.dinos.find(x=>x.id===m.dino.id);if(d){Object.assign(d,m.dino);d.wild=false;d.owner=owner||d.owner;}}if(m.kind==='breed'&&m.dino&&!scene.dinos.some(d=>d.id===m.dino.id)){const d=Object.assign(spawnDino(m.dino.type,m.dino.x,m.dino.z,false,m.dino.id),m.dino);d.wild=false;d.owner=owner||d.owner}}
  function handleNet(m,c){if(!m||!m.t)return;if(m.t==='hello'){if(net.host)c.send({t:'world',builds:scene.builds,farms:scene.farms,dinos:scene.dinos.filter(d=>!d.wild||d.boss).map(netDino)});}else if(m.t==='state'){scene.remotes.set(c.peer,{name:m.name,x:m.x,y:m.y,z:m.z,yaw:m.yaw,mounted:m.mounted});if(net.host&&m.mountedId){const md=scene.dinos.find(d=>d.id===m.mountedId);if(md&&md.owner===m.name){md.x=m.mx;md.z=m.mz;md.y=heightAt(md.x,md.z);md.yaw=m.myaw||md.yaw}}if(net.host)for(const [id,x] of net.connections)if(id!==c.peer&&x.open)x.send(m);updatePlayersUI()}else if(m.t==='world'){scene.builds=m.builds||scene.builds;scene.farms=m.farms||scene.farms;for(const nd of (m.dinos||[])){let d=scene.dinos.find(x=>x.id===nd.id);if(!d)d=Object.assign(spawnDino(nd.type,nd.x,nd.z,false,nd.id),nd);else Object.assign(d,nd)}for(const [id,p] of Object.entries(m.players||{}))scene.remotes.set(id,p);updatePlayersUI();}else if(m.t==='mutation'&&net.host){applyMutation(m,m.owner);broadcastWorld()}else if(m.t==='tameRequest'&&net.host){const d=scene.dinos.find(x=>x.id===m.dinoId);if(d){d.wild=false;d.owner=m.owner;d.name=species[d.type].name+' Companion';d.tame=999;broadcastWorld()}}else if(m.t==='breedRequest'&&net.host){const a=scene.dinos.find(d=>d.id===m.a),b=scene.dinos.find(d=>d.id===m.b);if(a&&b&&a.type===b.type&&!a.wild&&!b.wild){const s=species[a.type],id='baby-'+a.id+'-'+b.id+'-'+Math.floor(scene.time*10),baby=Object.assign(spawnDino(a.type,(a.x+b.x)/2,(a.z+b.z)/2,false,id),{wild:false,baby:true,born:scene.time,name:'Baby '+s.name,owner:m.owner,level:1,tame:999});baby.hp=baby.maxHp*=.55;baby.speed*=.55;broadcastWorld()}}}
  function syncNet(){const t=scene.time;if(!net.peer||t-net.lastSend<.08)return;net.lastSend=t;const m={t:'state',name:player.name,x:player.x,y:player.y,z:player.z,yaw:player.yaw,mounted:!!scene.mounted,mountedId:scene.mounted?.id||null,mx:scene.mounted?.x||null,mz:scene.mounted?.z||null,myaw:scene.mounted?.yaw||null};for(const c of net.connections.values())if(c.open)c.send(m);if(net.host&&t-net.lastWorld>.35){net.lastWorld=t;broadcastWorld()}}
  function updatePlayersUI(){const count=net.host?net.connections.size:scene.remotes.size;$('players').innerHTML=count?`<b>${count+1}</b> EXPEDITIONERS ONLINE`:'SOLO EXPLORER'}

  let audioCtx=null,ambientGain=null;
  function initAudio(){try{audioCtx=new (window.AudioContext||window.webkitAudioContext)();const buf=audioCtx.createBuffer(1,audioCtx.sampleRate*2,audioCtx.sampleRate),data=buf.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*.04;const src=audioCtx.createBufferSource();src.buffer=buf;src.loop=true;ambientGain=audioCtx.createGain();ambientGain.gain.value=.018;src.connect(ambientGain).connect(audioCtx.destination);src.start();}catch(e){}}
  function sfx(freq=440,dur=.08){if(!audioCtx)return;try{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='triangle';o.frequency.value=freq;g.gain.setValueAtTime(.035,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+dur);o.connect(g).connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+dur)}catch(e){}}
  function startGame(){
    if(!$('start').classList.contains('active')) return;
    try{
      $('start').classList.remove('active');$('start').classList.add('hidden');$('hud').classList.remove('hidden');
      player.name=($('name').value||'Explorer').trim().slice(0,16)||'Explorer';
      try{initAudio()}catch(e){console.warn('audio init',e)}
      player.y=heightAt(player.x,player.z);
      loadGame();updateHotbar();updateStats();updatePlayersUI();
      scene.running=true; loop.last=performance.now(); requestAnimationFrame(loop);
      if(!TEST){showNotice('Welcome to the frontier, '+player.name+'. Your camp is a safe zone.');setTimeout(()=>showTutorial(false),300);}
    }catch(e){
      console.error(e); const fatal=$('fatal'),txt=$('fatalText'); if(fatal){fatal.classList.remove('hidden');txt.textContent='The game hit a startup error: '+(e?.message||e)+'. Reload and try again.';}
    }
  }
  window.playDinoSolo=()=>startGame();
  window.hostDinoWorld=()=>setupHost();
  window.joinDinoWorld=()=>setupJoin($('room').value);
  $('soloBtn').onclick=()=>window.playDinoSolo(); $('hostBtn').onclick=()=>window.hostDinoWorld(); $('joinBtn').onclick=()=>window.joinDinoWorld();

  // time-of-day / weather
  function updateWorld(dt){scene.time+=dt;scene.day=(scene.day+dt*.0035)%1;if(Math.random()<dt*.015)scene.weather=1-scene.weather;scene.rain=lerp(scene.rain,scene.weather,dt*.2);for(const r of scene.resources)if(!r.active&&scene.time>r.respawn)r.active=true}

  function loop(t){if(!scene.running)return;const last=loop.last||t;const dt=Math.min(.035,(t-last)/1000);loop.last=t;scene.time=t/1000;updateWorld(dt);updatePlayer(dt);updateDinos(dt);updateSurvival(dt);updateFarms();questUpdate();syncNet();updateStats();const n=nearest();if(n){if(n.kind==='resource')$('prompt').textContent='E • Gather '+n.obj.type;else if(n.kind==='sceneryResource')$('prompt').textContent='E • Harvest '+(n.obj.kind==='tree'?'wood + fiber':'stone + clay');else if(n.kind==='dino')$('prompt').textContent=n.obj.boss?'E • Challenge '+species[n.obj.type].name:('E • '+(n.obj.wild?'Build trust with ':'Interact with ')+species[n.obj.type].name);else if(n.kind==='npc')$('prompt').textContent='E • Talk to '+n.obj.name;else $('prompt').textContent='E • '+(n.obj.grown?'Harvest garden':'Garden');}else $('prompt').textContent=scene.buildMode?'Click to place your selected structure':'Explore • Find resources • Tame a companion';if(scene.selected&&Math.hypot(scene.selected.x-player.x,scene.selected.z-player.z)>12){scene.selected=null;$('dinoCard').classList.add('hidden')}render();if(TEST&&scene.time>3){scene.running=false;document.body.dataset.test='pass';window.__DINO_FRONTIER__.booted=true;window.__DINO_FRONTIER__.checks={canvas:!!canvas,webgl:true,dinos:scene.dinos.length,terrain:!!MESH.terrain};console.log('DINO_FRONTIER_TEST_PASS',window.__DINO_FRONTIER__.checks);return}requestAnimationFrame(loop)}

  // Start menu is visible until action.
  window.addEventListener('error',e=>{window.__DINO_FRONTIER__.errors.push(String(e.error||e.message));console.error(e.error||e.message)});
  // keyboard polish
  setNetStatus(typeof Peer==='undefined'?'Multiplayer will load when you Host or Join.':'Multiplayer ready • Host or join a room.');
  requestAnimationFrame(loop);
})();
