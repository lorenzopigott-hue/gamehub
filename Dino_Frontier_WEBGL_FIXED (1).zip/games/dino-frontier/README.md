# Dino Frontier 3D — Competition Build

A browser-first original prehistoric survival game for GameHub.

## Controls
- WASD: move
- Mouse: camera
- Shift: sprint
- Space: jump
- E: interact / gather / tame
- B: build mode
- 1–4: building choice
- I: inventory + crafting
- M: map
- R: ride
- C: command
- N: breed
- T: tutorial

## Resource loop
- Trees: wood + fiber
- Rocks: stone + clay
- Glowing nodes: crystal, food, water
- Gardens: berries + seeds
- Water nodes: water + fish
- Crafting turns gathered materials into expedition gear and structures.

## Visual upgrades
- 3D explorer with hands, fingers, face, boots, backpack and hatchet
- More detailed dinosaurs with eyes, species-specific horns, plates, claws and teeth
- Procedural terrain color variation for jungle, coast, mesa and snow regions
- Ground contact shadows and stronger lighting/fog
- Richer resource node models

## Multiplayer
PeerJS is used for browser peer-to-peer connections. A shared host room is required for online co-op.

## Notes
This project uses original procedural geometry and does not include copyrighted ARK assets.
